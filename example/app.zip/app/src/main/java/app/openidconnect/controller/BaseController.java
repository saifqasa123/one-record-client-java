/**
 * File BaseController.java
 * 
 */
package app.openidconnect.controller;

import java.util.Map;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.ClientRegistration.ProviderDetails;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import app.openidconnect.Model.BaseSessionInformation;

/**
 * 
 * @author 
 *
 */
public class BaseController {
	
	private static final String ISSUER_URI = "issuer";
	private static final String JWKS_URI = "jwks_uri";
	private static final String TOKEN_URI = "token_endpoint";
	private static final String OIDC_APP_KEY = "wiseid";
	
	protected BaseSessionInformation baseSession;
	protected ClientRegistrationRepository clientRegistration;
	
	public BaseController(BaseSessionInformation baseSessionInformation, 
			ClientRegistrationRepository clientRegistrationRepository) {
        this.baseSession = baseSessionInformation;
        this.clientRegistration = clientRegistrationRepository;
    }
	
	/** Get token id */
	protected String getIdToken() {
		
		if (baseSession == null) {
			return "";
		}
		
		return baseSession.getIdToken();
	}
	
	/** Get authentication code */
	protected String getAuthenticationCode() {
		
		if (baseSession == null) {
			return "";
		}
		
		return baseSession.getAuthenticationCode();
	}
	
	/** Get token response from  token uri */
	protected String getTokenResponse() {
		
		if (baseSession == null) {
			return "";
		}
		
		return baseSession.getRaw();
	}
	
	/** Check is login */
	protected boolean isLogin() {
		String idToken = getIdToken();
		
		return !isStringEmpty(idToken);
	}
	
	/** Redirect to signout then login */
	protected String redirectLogin() {
		return "redirect:/signout";
	}
	
	/** Redirect to error page */
	protected String redirectError(String error, String details) {
		return "redirect:/cacheerror?error=" + error + "&details=" + details;
	}
	
	/** Get application configuration */
	protected ClientRegistration getAppConfig() {
		if (clientRegistration == null) {
			return null;
		}
		
		return clientRegistration.findByRegistrationId(OIDC_APP_KEY);
	}
	
	/** Get jwks uri from configuration */
	protected String getJwksUri() {
		
		Map<String, Object> metaData = getConfigMetadata();
		if (metaData == null) {
			return "";
		}
		
		if (!metaData.containsKey(JWKS_URI)) {
			return "";
		}
		
		return (String) metaData.getOrDefault(JWKS_URI, "");
	}

	/** Get token uri from configuration */
	protected String getTokenUri() {
		
		Map<String, Object> metaData = getConfigMetadata();
		if (metaData == null) {
			return "";
		}
		
		if (!metaData.containsKey(TOKEN_URI)) {
			return "";
		}
		
		return (String) metaData.getOrDefault(TOKEN_URI, "");
	}
	
	/** Get issuer uri from configuration */
	protected String getIssuerUri() {
		
		Map<String, Object> metaData = getConfigMetadata();
		if (metaData == null) {
			return "";
		}
		
		if (!metaData.containsKey(ISSUER_URI)) {
			return "";
		}
		
		return (String) metaData.getOrDefault(ISSUER_URI, "");
	}
	
	/** Check a string is empty, null or white space */
	protected boolean isStringEmpty(String str) {
		
		if (str == null) return true;
		if ("".equals(str)) return true;
		String temp = str + "";
		str = temp.trim();
		if ("".equals(str)) return true;
		return false;
	}
	
	/**  */
	protected <T> String getJsonPrettyInString(T obj) {
		try {
			if (obj == null) {
				return "";
			}
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
	        return gson.toJson(obj);
		} catch (Exception e) {
			return "";
		}
	}
	
	/**  */
	protected <T> T loadJson(String jsonString, Class<T> targetType) {
	    try {
	    	if (isStringEmpty(jsonString)) {
				return null;
			}
			
	    	Gson converter = new Gson();
	    	T data = converter.fromJson(jsonString, targetType);
	        return data;
		} catch (Exception e) {
			return null;
		}
	}
	
	/**  */
	private Map<String, Object> getConfigMetadata(){
		ClientRegistration config = getAppConfig();
		if (config == null) {
			return null;
		}
		
		ProviderDetails details = config.getProviderDetails();
		
		if (details == null) {
			return null;
		}
		
		return details.getConfigurationMetadata();
	}
	
}
