package app.openidconnect.Model;

public class ApiResult {
	
	private int productID;
	private long price;
	private int quantity;
	
	public int getProductID() {
		return this.productID;
	}
	
	public void setProductID(int data) {
		this.productID = data;
	}
	
	public long getPrice() {
		return this.price;
	}
	
	public void setPrice(long data) {
		this.price = data;
	}
	
	public int getQuantity() {
		return this.quantity;
	}
	
	public void setQuantity(int data) {
		this.quantity = data;
	}
	
}
