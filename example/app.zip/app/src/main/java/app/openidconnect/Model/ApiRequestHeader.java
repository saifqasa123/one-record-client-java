package app.openidconnect.Model;

public class ApiRequestHeader {
	
	public ApiRequestHeader(String Authorization) {
		this.Authorization = Authorization;
	}
	
	private String Authorization;
	
	public String getAuthorization() {
		return this.Authorization;
	}
	
}
