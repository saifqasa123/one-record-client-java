package app.openidconnect.Model;

import java.util.List;

public class ApiAuthenticatedSubject {
	
	private String type;
	private String subjectDN;
	private String validFrom;
	private String validTo;
	private String issuerDN;
	private String lastAuthenticatedAt;
	private String validationService;
	private List<String> sans;
	
	public String getType() {
		return this.type;
	}
	
	public void setType(String data) {
		this.type = data;
	}
	
	public String getSubjectDN() {
		return this.subjectDN;
	}
	
	public void setSubjectDN(String data) {
		this.subjectDN = data;
	}
	
	public String getValidFrom() {
		return this.validFrom;
	}
	
	public void setValidFrom(String data) {
		this.validFrom = data;
	}
	
	public String getValidTo() {
		return this.validTo;
	}
	
	public void setValidTo(String data) {
		this.validTo = data;
	}
	
	public String getIssuerDN() {
		return this.issuerDN;
	}
	
	public void setIssuerDN(String data) {
		this.issuerDN = data;
	}
	
	public String getLastAuthenticatedAt() {
		return this.lastAuthenticatedAt;
	}
	
	public void setLastAuthenticatedAt(String data) {
		this.lastAuthenticatedAt = data;
	}
	
	public String getValidationService() {
		return this.validationService;
	}
	
	public void setValidationService(String data) {
		this.validationService = data;
	}
	
	public List<String> getSans() {
		return this.sans;
	}
	
	public void setSans(List<String> data) {
		this.sans = data;
	}
}
