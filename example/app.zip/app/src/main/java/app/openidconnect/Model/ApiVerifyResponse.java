package app.openidconnect.Model;

public class ApiVerifyResponse {
	
	private ApiAuthenticatedSubject authenticatedSubject;
	private ApiResult result;
	private long timestamp;
	private String message;
	private String details;
	
	public ApiAuthenticatedSubject getAuthenticatedSubject() {
		return authenticatedSubject;
	}
	
	public void setAuthenticatedSubject(ApiAuthenticatedSubject data) {
		this.authenticatedSubject = data;
	}
	
	public ApiResult getResult() {
		return result;
	}
	
	public void setResult(ApiResult data) {
		this.result = data;
	}
	
	public long getTimestamp() {
		return this.timestamp;
	}
	
	public void setResult(long data) {
		this.timestamp = data;
	}
	
	public String getMessage() {
		return this.message;
	}
	
	public void setMessage(String data) {
		this.message = data;
	}
	
	public String getDetails() {
		return this.details;
	}
	
	public void setDetails(String data) {
		this.details = data;
	}
	
}
